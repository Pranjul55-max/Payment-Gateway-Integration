package com.security.Security.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.security.Security.models.user;

@Service
public class service {
	
	List <user> list= new ArrayList<>(); 
	public service() {
		list.add(new user("abc","abc","abc@gmail.com"));
		list.add(new user("xyz","xyz","xyz@gmail.com"));
	}
	
	public List<user> getAllUsers(){
		return this.list;
	}
	
	public user getUser(String name) {
		return this.list.stream().filter((user)->user.getName().equals(name)).findAny().orElse(null);
	}
	
	public user addUser(user User) {
		this.list.add(User); 
		return User;
	}

}
