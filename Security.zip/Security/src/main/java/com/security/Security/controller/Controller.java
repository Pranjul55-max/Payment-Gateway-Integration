package com.security.Security.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.Security.Services.service;
import com.security.Security.models.user;

@RestController
@RequestMapping("/users")
public class Controller {

	@Autowired
	private service Service;
	
	@GetMapping("/")
	public List<user> getAllUsers(){
		return this.Service.getAllUsers();
	}
	
	@GetMapping("/{name}")
	public user getUser(@PathVariable("name") String name) {
		return this.Service.getUser(name);
	}
	
	@PostMapping("/")
	public user addUser(@RequestBody user User) {
		return this.Service.addUser(User);
	}
}
