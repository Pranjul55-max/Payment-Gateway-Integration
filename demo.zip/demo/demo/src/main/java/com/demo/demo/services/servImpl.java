package com.demo.demo.services;

//import java.util.ArrayList;
import java.util.List;
//import java.util.stream.Collectors;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.demo.dao.courseDao;
import com.demo.demo.entities.Course;

@Service 
public class servImpl implements courseService {

	@Autowired 
	private courseDao Coursedao;
//	List<Course> list;
	public servImpl() {
	//	list= new ArrayList<>();
	//	list.add(new Course(1, "Java", "This is a java course"));
	//	list.add(new Course(2, "C++", "This is a c++ course"));
	}
	@Override
	public List<Course> getCourses() {
		
		//return list;
		return Coursedao.findAll();
	}
	@Override
	public Course getCourse(long courseId) {
	//	Course c=null;
	//	for(Course course:list) {
	//		if(course.getId()==courseId) {
	//			c=course;
	//			break;
	//		}
	//	}
	//	return c;
		Optional<Course> optional= Coursedao.findById(courseId);
		Course course=optional.get();
		return course;
	}
	@Override
	public Course addCourse(Course course) {
	//	list.add(course);
	//	return course;
		Coursedao.save(course);
		return course;
	}
	
	@Override
	public Course updateCourse(Course course) {
	//	list.forEach(e->{
	//		if(e.getId()==course.getId()) {
	//			e.setTitle(course.getTitle());
	//			e.setDesc(course.getDesc());
	//		}
	//	});
		
	//	return course;
		
		Coursedao.save(course);
		return course;
	}
	@Override
	public void deleteCourse(long parseLong) {
	//	list=this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList());
		
		@SuppressWarnings("deprecation")
		Course entity= Coursedao.getOne(parseLong);
		Coursedao.delete(entity);
	}
	
	

}
