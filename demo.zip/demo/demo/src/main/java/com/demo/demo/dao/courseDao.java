package com.demo.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.demo.entities.Course;

public interface courseDao extends JpaRepository<Course,Long> {

}
